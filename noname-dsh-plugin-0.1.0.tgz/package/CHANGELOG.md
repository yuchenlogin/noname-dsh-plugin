# Changelog

## [0.1.2] - 2026-10-08

### Fixes（复审驱动：架构 74→90 后的剩余 10 分）

- **ingest 串行化**：并发 ingest 竞争 SQLite 单写者锁（`database is locked`）导致证据丢失 + dedup 测试确定性失败——用 promise 链串行化写入，证据流有序不丢；新增 `drainIngests` 测试钩子消除时序竞态。
- **截断标记**：ingest 500 字截断现在追加 `… [truncated, full in DSH transcript]`——「压缩可以有损，呈现不能撒谎」，读者知道这是采样（理念诚实的最后 1%）。
- **inFlight 死代码删除**：`index.ts` 的 AbortController 池从未接线到任何调用——卸载时 abort 一个永远为空的集合是谎言。删除并注释说明（sidecar 调用短生命周期 + 各自 abort 路径已覆盖），宣称的卸载行为与实现一致。
- **git 历史清洗**：filter-repo 移除首 commit 误提交的 node_modules/dist（.git 21MB → 904KB，1675 个对象清零），开箱体验干净。
- **分支与 CI 对齐**：master → main，与 workflow 触发器一致。
- **README**：补 license 章节（落实 CHANGELOG 0.1.1 的宣称）、iframe 表述对齐（渲染方式由宿主决定）。

### Notes & Caveats

- 24 测试全绿（ingest 5/5 稳定）；真实 Cordis Context 加载冒烟通过。
- 剩余已知边界（诚实标注、非缺陷）：sidebar keyed-slot 正文待真实 DSH 宿主验证、审批门/品味卡图像/多 profile 账本属后续版本。

## [0.1.1] - 2026-10-08

### Fixes（三方评审驱动：DSH 官方 QA 28/100、GitHub 开发者 52/100、架构 74/100）

本轮修复全部针对「宣称与实现断裂」——对一个把诚实刻进账本哲学的系统，这类问题比 bug 更重。

**加载阻断级（critical）**
- **inject 缺失即崩**：`apply()` 在真实 Cordis `Context` 下访问未注入的 `ctx.sidebarRightTabs` 直接抛错，整个插件加载失败（stub 测试给了虚假信心）。修复：sidebar 访问收进 `ctx.effect` 内做防御性降级，真实 Cordis 加载冒烟验证通过（apply OK、11 工具注册、kernel ping 成功）。
- **dbDir 默认值空头支票**：README 承诺 `$DSH_HOME/noname`，实现是 `?? ""`——零配置下每次调用都 `mkdir("")` ENOENT。修复：`resolveConfig` 在单一边界落地真实默认值（`$DSH_HOME/noname` 或 `~/.dsh/noname`），绝不写宿主 CWD 或内核 submodule。
- **Git 安装路径必坏**：`main` 指向 `dist/` 但无 `prepare`。修复：补 `prepare`/`prepack` 自动 build，git 安装可直接加载。

**协议/理念不符（high）**
- **sidebar 注册凭空猜 API**：改为按真实契约（静态定义 `sidebarRightTabs.register` + 明确标注 keyed-slot 正文需真机验证），不再假装有 `render()` 全功能。
- **Config 假 zod**：接真实 `@deepseek-ai/schemastery` schema，加载边界校验，非法值响亮报错。
- **ingest 丢溯源**：所有事件灌进硬编码 `session "dsh"`，抹掉谱系——改为按真实 DSH 会话 id 归属（`exec.sessionId`）。
- **ingest 静默丢证据**：catch 后无声——改为 warn + 计数 + 重入队（失败不标记 seen），「绝不影响宿主」但「绝不无痕丢失」。
- **假 verbose 档**：`minimal`/`verbose` 行为全同——删除该枚举，只保留真实的一档。
- **品味只铺单轨**：补 `taste_propose`（adopted 轨，模型从「眼前一亮的时刻」发起）、`taste_review`（生命周期）、`card_queue`（复核队列）——双轨与复核链完整。
- **HTML 只增不减**：`noname-ledger-${Date.now()}.html` 无限堆积——改为固定文件名 + `--overwrite` 覆盖写。

**工程基建（GitHub 开发者视角）**
- 补 MIT LICENSE（内核 license 兼容性在 README 标注）；package.json 补 repository/bugs/author/homepage/engines；files 补 README/LICENSE/CHANGELOG。
- 新增 `.github/workflows/test.yml`：2 OS × 2 Node × 2 Python 矩阵，插件测试（真内核）+ 内核 628 测试。

### Design Rationale

- **为什么 sidebar 降级而非硬凑**：真实 keyed-slot + useTabInfo 契约无法在无 DSH 宿主时验证；与其交付一个「画出来的地图」，不如按文档化的静态定义注册并诚实标注待真机验证——界面是地图，但地图不能是画的。
- **为什么 ingest 失败要 warn 而非静默**：「绝不影响宿主会话」与「绝不无痕丢证据」不矛盾——一个以「证据不丢」为存在理由的系统，丢证据时必须留痕。

### Notes & Caveats

- 测试 17 → 24 全绿（新增 ingest 诚实性 4 项 + 插件加载面 3 项）；真实 Cordis `Context` 加载冒烟通过。
- 待办：git 历史清洗（首 commit 误含 node_modules，发布前 filter-repo）、推送远端激活 README 链接、sidebar keyed-slot 真机验证。

## [0.1.0] - 2026-10-08

### Features

- 首个可用版本：NoName Agent Harness 作为 DeepSeek Harness 插件（Hybrid 架构——Python sidecar 内核 + TS 原生工具/UI 层）。
- Python sidecar 桥（`kernel.ts`）：`python -m noname_harness` 子进程 + stdout JSON 契约（raw 模式支持 `package`/`ledger` 非 JSON 输出），错误按 spawn_failed/nonzero_exit/bad_json/timeout/aborted 分类，含 pre-aborted signal 守卫与幂等 init。
- 8 个模型可见工具：record/package/search/state/inbox/taste_add/verify/extract。
- 事件自动入账（可配置开关 + minimal/verbose 级别 + callId 幂等去重 + 失败不影响宿主会话）。
- 账本面板：右侧 sidebar tab 嵌入 NoName 五视图 HTML（iframe，内核自渲染保真）。
- 插件配置（zod）：pythonPath/dbDir/autoIngest/ingestLevel，设置卡片可编辑。

### Design Rationale

- **Hybrid 而非纯 TS 重写**：NoName 内核 11,360 行生产代码 + 12,400 行测试经 28 轮对抗性审查 + 2 轮暴力测试加固；重写意味着数周工作 + 翻译走样风险 + 放弃已验证资产。内核以 git submodule 零改动引入，TS 层只做薄适配。
- **UI 嵌入内核 HTML 而非 TS 重渲染**：账本五视图是 NoName 自己的设计哲学（克制、渐进披露、"审核是签署"），TS 重绘只会失真；iframe 嵌入保持与 `ledger-html` 完全一致。

### Notes & Caveats

- 17 项插件层测试全绿（vitest，含真内核端到端：record→extract→propose→package 跨会话接续、五视图渲染、verify）；内核 628 测试保持全绿（submodule 不动）。
- 依赖系统 python3（内核无外部依赖）；DSH 插件运行时需要 child_process.spawn 能力。
- 首版不含：审批门在 DSH 侧的专用 UI、品味卡图像面板、多 profile 共享账本。
